// 显示充电方式选择后的动态更新
document.getElementById('chargeMethod').addEventListener('change', function() {
    var chargeMethod = this.value;
    if (chargeMethod === 'charger') {
        document.getElementById('chargerCurrentDiv').style.display = 'block';
        document.getElementById('sunHours').disabled = true;  // 禁用太阳照射时间输入框
        document.getElementById('solarPower').disabled = true;  // 禁用太阳能输入框
    } else {
        document.getElementById('chargerCurrentDiv').style.display = 'none';
        document.getElementById('sunHours').disabled = false;  // 启用太阳照射时间输入框
        document.getElementById('solarPower').disabled = false;  // 启用太阳能输入框
    }
});

function calculate() {
    // 获取输入框的值
    const solarPower = document.getElementById('solarPower').disabled ? 0 : parseFloat(document.getElementById('solarPower').value);  // 禁用时返回 0
    const batteryCapacity = parseFloat(document.getElementById('batteryCapacity').value);
    const batteryVoltage = parseFloat(document.getElementById('batteryVoltage').value);
    const batteryType = document.getElementById('batteryType').value;
    const dayLoadPower = parseFloat(document.getElementById('dayLoadPower').value);
    const nightLoadPower = parseFloat(document.getElementById('nightLoadPower').value);
    const sunHours = document.getElementById('sunHours').disabled ? 0 : parseFloat(document.getElementById('sunHours').value);  // 禁用时返回 0
    const chargeMethod = document.getElementById('chargeMethod').value;
    const chargerCurrent = parseFloat(document.getElementById('chargerCurrent').value);

    // 检查必需的输入值是否有效
    if (isNaN(solarPower) || isNaN(batteryCapacity) || isNaN(batteryVoltage) || isNaN(dayLoadPower) || isNaN(nightLoadPower) ||
        (chargeMethod === 'solar' && isNaN(sunHours)) || (chargeMethod === 'charger' && isNaN(chargerCurrent))) {
        alert("请确保所有必需的输入框都已填写！");
        return;
    }

    let depthOfDischarge;
    let chargingEfficiency;
    const solarPanelEfficiency = 0.9;

    // 根据电池类型设置深度放电和充电效率
    if (batteryType === "lithium") {
        depthOfDischarge = 0.9;
        chargingEfficiency = 0.9;
    } else {
        depthOfDischarge = 0.7;
        chargingEfficiency = 0.7;
    }

    const batteryEnergy = batteryCapacity * batteryVoltage;
    const usableEnergy = batteryEnergy * depthOfDischarge;

    const dayEnergyUsage = dayLoadPower * sunHours;
    const nightEnergyUsage = nightLoadPower * (24 - sunHours);

    const solarDailyEnergy = solarPower * sunHours * solarPanelEfficiency;

    let chargeTime = 0;
    let dayTime = 0;
    let nightTime = 0;

    if (chargeMethod === "solar") {
        chargeTime = batteryEnergy / (solarPower * chargingEfficiency);
        dayTime = solarDailyEnergy / dayLoadPower;  // Solar power during the day
        nightTime = usableEnergy / nightLoadPower;  // Solar power during the night
    } else if (chargeMethod === "charger" && !isNaN(chargerCurrent)) {
        chargeTime = batteryCapacity / chargerCurrent;
        // 使用充电器的功率
        dayTime = (solarPower * sunHours) / dayLoadPower || 0;  // Charger power during the day (use charger current)
        nightTime = 0;  // 充电器充电时，夜间时间设为 0
    }

    // 确保 dayTime 和 nightTime 都是有效数字
    if (isNaN(dayTime)) dayTime = 0;
    if (isNaN(nightTime)) nightTime = 0;

    // 输出计算结果
    document.getElementById('chargeTime').textContent = `ဘက်ထရီအားအပြည့်သွင်းရန် လိုအပ်သည့်အချိန်：${chargeTime.toFixed(2)} နာရီ`;
    document.getElementById('dayTime').textContent = `နေ့ဘက် စက်ပစ္စည်းအတွက် လည်ပတ်မှုကို ထောက်ပံ့ပေးနိုင်ချိန်：${dayTime.toFixed(2)} နာရီ`;
    document.getElementById('nightTime').textContent = `ညဘက်ဘက်ထရီမှ စက်ပစ္စည်းများကို ထောက်ပံ့ပေးနိုင်ချိန်：${nightTime.toFixed(2)} နာရီ`;

    // 显示建议
    if (solarDailyEnergy >= dayEnergyUsage) {
        document.getElementById('dayAdvice').textContent = `အကြံပြုချက်- နေ့ဘက်တွင် စက်ပစ္စည်းများ၏ လိုအပ်ချက်များကို အပြည့်အဝ ဖြည့်ဆည်းပေးနိုင်သည်။`;
        document.getElementById('dayAdvice').style.color = 'green';
    } else {
        document.getElementById('dayAdvice').textContent = `အကြံပြုချက်- ညဘက်တွင် စက်ပစ္စည်းများ၏ လိုအပ်ချက်များကို ဖြည့်ဆည်းရန် လုံလောက်မှု မရှိပါ ၊ ဆိုလာပြားများ၏ ပါဝါကို တိုးမြှင့်ရန် သို့မဟုတ် နေ့ဘက်တွင် လျှပ်စစ်ပစ္စည်းများ၏ ပါဝါကို လျော့ချရန် အကြံပြုထားသည်။`;
        document.getElementById('dayAdvice').style.color = 'red';
    }

    if (nightTime < 12) {
        document.getElementById('nightAdvice').textContent = `အကြံပြုချက်- ညဘက်တွင် ဘက်ထရီသက်တမ်း မလုံလောက်ပါ ဘက်ထရီပမာဏကို တိုးမြှင့်ရန် သို့မဟုတ် ညအချိန်တွင် အသုံးပြုသည့် လျှပ်စစ်ပစ္စည်းများ၏ ပါဝါကို လျော့ချ အသုံးပြုရန် အကြံပြုပါသည်။`;
        document.getElementById('nightAdvice').style.color = 'red';
    } else {
        document.getElementById('nightAdvice').textContent = `အကြံပြုချက်- ဘက်ထရီပမာဏသည် ညဘက်တွင် လျှပ်စစ်ပစ္စည်းများ၏လိုအပ်သည့်ပါဝါကိုအပြည့်အဝ ထောက်ပံ့ပေးနိုင်သည်။`;
        document.getElementById('nightAdvice').style.color = 'green';
    }
}